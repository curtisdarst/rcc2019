﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Amazon;
using Amazon.SimpleEmail;

using Amazon.SimpleEmail.Model;
namespace AWSServerlessAPIProject.Controllers
{
    [Route("v1/workouts")]
     public class WorkoutsController : Controller
    {
        // GET v1/workouts
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value11", "value21" };
        }

        // GET v1/workouts/cdd

         // maybe try a secret user???? *hint hint
        [HttpGet("{id}")]
        public string Get(string id)
        {

            string connetionString = null;
            string sqlMessage = null;
            SqlConnection sqlconnection;
            connetionString = "";
            sqlMessage = "SELECT TOP 1 * from workouts where twitterHandle = '" + id + "' order by workoutDate desc FOR JSON AUTO, Without_Array_Wrapper;";

            sqlconnection = new SqlConnection(connetionString);
            sqlconnection.Open();
            SqlCommand command = new SqlCommand(sqlMessage, sqlconnection);
            ViewData["results"] = "";

            var jsonResult = new StringBuilder();
            var reader = command.ExecuteReader();
            if (!reader.HasRows)
            {
                jsonResult.Append("[]");
            }
            else
            {
                while (reader.Read())
                {
                    jsonResult.Append(reader.GetValue(0).ToString());
                }
            }

            sqlconnection.Close();
            return jsonResult.ToString();
        }

        // POST v1/workouts
        [HttpPost]
        public void Post([FromBody]string value)
        {
           
        }

        // PUT v1/workouts/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
            // Replace sender@example.com with your "From" address.
            // This address must be verified with Amazon SES.
            string senderAddress = "sender@example.com"; 

            // Replace recipient@example.com with a "To" address. If your account
            // is still in the sandbox, this address must be verified.
             string receiverAddress = "sender@example.com";

            // The configuration set to use for this email. If you do not want to use a
            // configuration set, comment out the following property and the
            // ConfigurationSetName = configSet argument below. 
            string configSet = "ConfigSet";

            // The subject line for the email.
            string subject = "Amazon SES test (RCC2019)";

            // The email body for recipients with non-HTML email clients.
            string textBody = "Amazon SES Test (.NET)\r\n"
                                            + "This email was sent through Amazon SES "
                                            + "using the AWS SDK for .NET.";

            // The HTML body of the email.
            string htmlBody = @"<html>
<head></head>
<body>
  <h1>Amazon SES Test (AWS SDK for .NET)</h1>
  <p>This email was sent with
    <a href='https://aws.amazon.com/ses/'>Amazon SES</a> using the
    <a href='https://aws.amazon.com/sdk-for-net/'>
      AWS SDK for .NET</a>.</p>
</body>
</html>";



            using (var client = new AmazonSimpleEmailServiceClient(RegionEndpoint.USEast1))
            {
                var sendRequest = new SendEmailRequest
                {
                    Source = senderAddress,
                    Destination = new Destination
                    {
                        ToAddresses =
                        new List<string> { receiverAddress }
                    },
                    Message = new Message
                    {
                        Subject = new Content(subject),
                        Body = new Body
                        {
                            Html = new Content
                            {
                                Charset = "UTF-8",
                                Data = htmlBody
                            },
                            Text = new Content
                            {
                                Charset = "UTF-8",
                                Data = textBody
                            }
                        }
                    },
                    // If you are not using a configuration set, comment
                    // or remove the following line 
                    ConfigurationSetName = configSet
                };
                try
                {
                    Console.WriteLine("Sending email using Amazon SES...");
                    var response = client.SendEmailAsync(sendRequest);
                    Console.WriteLine("The email was sent successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("The email was not sent.");
                    Console.WriteLine("Error message: " + ex.Message);

                }
            }

        }

        // DELETE v1/workouts/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}