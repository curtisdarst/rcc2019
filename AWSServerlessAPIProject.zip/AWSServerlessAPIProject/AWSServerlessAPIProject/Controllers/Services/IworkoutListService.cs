﻿namespace AWSServerlessAPIProject.Controllers.Services
{
    public class IworkoutListService
    {
    }
}