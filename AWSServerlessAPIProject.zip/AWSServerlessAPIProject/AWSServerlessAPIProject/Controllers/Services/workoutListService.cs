﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWSServerlessAPIProject.Controllers.Services
{
    public class workoutListService : IworkoutListService
    {
        private readonly Dictionary<string, int> workoutListStorage = new Dictionary<string, int>();
        public Dictionary<string, int> GetItemsFromWorkoutList()
        {
            return workoutListStorage;
        }
    }
}
