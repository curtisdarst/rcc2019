﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AWSServerless2.Pages
{
    public class TopUserListModel : PageModel
    {
        
        public void OnGet()
        {
            ViewData["results"] = "List Generating";

            string connetionString = null;
            string sqlMessage = null;
            SqlConnection sqlconnection;
            connetionString = "Data Source=mssqlnotserver.c8i9wczc98vn.us-east-1.rds.amazonaws.com;Initial Catalog=workouttracker;User ID=dotNetWebUser;Password=2mT90QN0mOKFemDb83QF";
            sqlMessage = "SELECT TOP 10 * FROM workouts order by workoutDate desc";
            sqlconnection = new SqlConnection(connetionString);
            sqlconnection.Open();
            SqlCommand command = new SqlCommand(sqlMessage, sqlconnection);
            ViewData["results"] = "";
            ViewData["results"] += "<ul>";
            //Need to loop across all records 
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    ViewData["results"] += "<li>Workout: " + (String.Format("{0}", reader["workoutType"])) + "\n";
                    ViewData["results"] += "Count: " + (String.Format("{0}", reader["workoutCount"])) + "\n";
                    ViewData["results"] += "Handle: " + (String.Format("{0}", reader["twitterHandle"])) + "\n</li>";
                    ViewData["results"] += "\n\n";
                }
            }
            ViewData["results"] += "</ul>";
            sqlconnection.Close();
        }
    }
}