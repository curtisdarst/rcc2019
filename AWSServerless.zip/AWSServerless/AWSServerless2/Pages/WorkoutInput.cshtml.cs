﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AWSServerless2.Pages
{
    public class WorkoutInputModel : PageModel
    {
        public void OnGet()
        {

        }

        public void OnPost()
        {
            string connetionString = null;
            string sqlMessage = null;
            SqlConnection sqlconnection;
            connetionString = "Data Source=mssqlnotserver.c8i9wczc98vn.us-east-1.rds.amazonaws.com;Initial Catalog=workouttracker;User ID=dotNetWebUser;Password=2mT90QN0mOKFemDb83QF";
            sqlMessage = "Insert into workouts (twitterHandle " +
                "          ,workoutType" +
                "          ,workoutDate" +
                "          ,workoutCount) " +
                "VALUES(@twitter," +
                "       @workoutType," +
                "       @workoutDate," +
                "       @workoutCount)";

            sqlMessage = "INSERT INTO workouts (twitterHandle,workoutType,workoutDate,workoutCount) " +
                "VALUES('"+ Request.Form["name"] + "','"+ Request.Form["type"] + "','" + Request.Form["workoutdate"] + "'," + Request.Form["count"] + ")";
            
            sqlconnection = new SqlConnection(connetionString);
            SqlCommand cmd = new SqlCommand(sqlMessage, sqlconnection);
            sqlconnection.Open();
            cmd.ExecuteNonQuery();
            sqlconnection.Close();

        }
    }
}